package loganalyzer;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

public class LogAnalyzer {

    private List<String> logs;

    public LogAnalyzer() {
        logs = new ArrayList<>();
    }

    // Load logs from a file named "logs.txt"
    public void loadLogs(String fileName) {
        try (BufferedReader reader = new BufferedReader(new FileReader(fileName))) {
            String line;

            while ((line = reader.readLine()) != null) {
                logs.add(line);
            }

        } catch (IOException e) {
            System.out.println("Error reading file: " + e.getMessage());
        }
    }

    // Display all logs
    public void displayLogs() {
        for (String log : logs) {
            System.out.println(log);
        }
    }

    public static void main(String[] args) {
        LogAnalyzer analyzer = new LogAnalyzer();

        analyzer.loadLogs("logs.txt");
        analyzer.displayLogs();
    }
}