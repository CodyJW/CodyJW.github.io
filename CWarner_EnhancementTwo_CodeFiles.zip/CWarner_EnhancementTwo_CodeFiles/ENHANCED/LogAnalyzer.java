package loganalyzer;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class LogAnalyzer {

    // How many failed attempts before an IP is flagged as suspicious
    private static final int SUSPICIOUS_IP = 3;

    // Stores every line from the file
    private List<String> logs;

    // Maps each IP address to its failed login count
    private HashMap<String, Integer> failedAttempts;

    public LogAnalyzer() {
        logs = new ArrayList<>();
        failedAttempts = new HashMap<>();
    }

    // Reads the log file and stores each line in the logs list.
    public void loadLogs(String fileName) {
        try (BufferedReader reader = new BufferedReader(new FileReader(fileName))) {
            String line;
            while ((line = reader.readLine()) != null) {
                logs.add(line);
            }
        } catch (IOException e) {
            System.out.println("Error reading file: " + e.getMessage());
        }
    }

    // Parses each log entry and counts failed login attempts per IP address.
    // Each entry is expected to have the format: <IP> <SUCCESS/FAILED>
    // Entries that do not match that format are skipped but still noted for report.
    public void analyzeLogs() {
        for (String log : logs) {
            String[] parts = log.split(" ");

            // Skip any line that does not have exactly two parts
            if (parts.length != 2) {
                System.out.println("Skipped malformed entry: " + log);
                continue;
            }

            String ip = parts[0];
            String event = parts[1];

            // Counts failed login events
            if (event.equals("FAILED")) {
                if (failedAttempts.containsKey(ip)) {
                    failedAttempts.put(ip, failedAttempts.get(ip) + 1);
                } else {
                    failedAttempts.put(ip, 1);
                }
            }
        }
    }

    // Prints report showing each IP, its failed attempt count, whether it is flagged as suspicious, and the total across all IPs.
    // Sorted from highest to lowest failed attempt count.
    public void printReport() {
        System.out.println("\n-----------------------------------------------------");
        System.out.println("             Failed Login Summary Report");
        System.out.println("-----------------------------------------------------");

        // Convert the HashMap entries to a list so they can be sorted
        List<Map.Entry<String, Integer>> sortedEntries = new ArrayList<>(failedAttempts.entrySet());

        // Sort by failed attempt count, highest first
        Collections.sort(sortedEntries, (a, b) -> b.getValue() - a.getValue());

        int total = 0;

        for (Map.Entry<String, Integer> entry : sortedEntries) {
            String ip = entry.getKey();
            int count = entry.getValue();
            total += count;

            // Adds SUSPICIOUS tag if there is 3 or more failed attempts
            String flag = "";
            if (count >= SUSPICIOUS_IP) {
                flag = " ** SUSPICIOUS **";
            }

            System.out.println("IP: " + ip + " | Failed Attempts: " + count + flag);
        }

        System.out.println("-----------------------------------------------------");
        System.out.println("Total failed attempts: " + total);
    }

    public static void main(String[] args) {
        LogAnalyzer analyzer = new LogAnalyzer();

        analyzer.loadLogs("logs.txt"); // File name to read from
        analyzer.analyzeLogs();
        analyzer.printReport();
    }
}
