package com.example.codywarner_weighttrackerapp;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import android.Manifest;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.database.Cursor;
import android.graphics.Color;
import android.os.Bundle;
import android.telephony.SmsManager;
import android.widget.Button;
import android.widget.EditText;
import android.widget.GridLayout;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import androidx.core.content.ContextCompat;

public class WeightGridActivity extends AppCompatActivity {

    // UI
    private GridLayout weightGrid;
    private Button buttonAddEntry;

    // database
    private WeightTrackerDBHelper dbHelper;

    // Current logged in user
    private String username;
    private int userId = -1;

    // Bottom nav tabs
    private TextView tabDailyWeights;
    private TextView tabProgressGraph;
    private TextView tabGoal;
    private TextView tabSettings;

    // Header cells (Date/Weight/Delete)
    private static final int HEADER_CELL_COUNT = 3;

    // Saved SMS settings
    private static final String PREFS_SMS = "sms_prefs";
    private static final String KEY_SMS_ENABLED = "sms_enabled";
    private static final String KEY_GOAL_ALERT = "goal_alert";

    // Saved goal weight
    private static final String PREFS_WT = "wt_prefs";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_weight_grid);

        // Get username from login screen
        username = getIntent().getStringExtra("username");
        if (username == null || username.trim().isEmpty()) {
            Toast.makeText(this, "No user found.", Toast.LENGTH_SHORT).show();
            finish();
            return;
        }

        // Set up database + find user id
        dbHelper = new WeightTrackerDBHelper(this);
        userId = dbHelper.getUserId(username);

        if (userId == -1) {
            Toast.makeText(this, "Could not load account.", Toast.LENGTH_SHORT).show();
            finish();
            return;
        }

        // Hook up views
        weightGrid = findViewById(R.id.weightGrid);
        buttonAddEntry = findViewById(R.id.buttonAddEntry);

        // Hook up bottom nav views
        tabDailyWeights = findViewById(R.id.tabDailyWeights);
        tabProgressGraph = findViewById(R.id.tabProgressGraph);
        tabGoal = findViewById(R.id.tabGoal);
        tabSettings = findViewById(R.id.tabSettings);

        // Turn on nav behavior and highlight current tab
        setupBottomNav("daily");

        // Fill the grid with saved weights
        loadWeightsFromDatabase();

        // Add a new weight entry
        buttonAddEntry.setOnClickListener(v -> showAddEntryDialog());
    }

    @Override
    protected void onResume() {
        super.onResume();
        // Refresh when coming back from other screens
        loadWeightsFromDatabase();
    }

    private void setupBottomNav(String activeTab) {
        // Simple highlight for the current tab
        int activeColor = Color.WHITE;
        int inactiveColor = Color.parseColor("#FFD6DE");

        tabDailyWeights.setTextColor(inactiveColor);
        tabProgressGraph.setTextColor(inactiveColor);
        tabGoal.setTextColor(inactiveColor);
        tabSettings.setTextColor(inactiveColor);

        switch (activeTab) {
            case "daily":
                tabDailyWeights.setTextColor(activeColor);
                break;
            case "progress":
                tabProgressGraph.setTextColor(activeColor);
                break;
            case "goal":
                tabGoal.setTextColor(activeColor);
                break;
            case "settings":
                tabSettings.setTextColor(activeColor);
                break;
        }

        // Daily = this screen
        tabDailyWeights.setOnClickListener(v -> {
            // already here
        });

        // Go to progress screen
        tabProgressGraph.setOnClickListener(v -> {
            Intent i = new Intent(WeightGridActivity.this, ProgressActivity.class);
            i.putExtra("username", username);
            startActivity(i);
        });

        // Go to goal screen
        tabGoal.setOnClickListener(v -> {
            Intent i = new Intent(WeightGridActivity.this, GoalActivity.class);
            i.putExtra("username", username);
            startActivity(i);
        });

        // Go to SMS settings screen
        tabSettings.setOnClickListener(v -> {
            Intent i = new Intent(WeightGridActivity.this, SmsNotificationActivity.class);
            i.putExtra("username", username);
            startActivity(i);
        });
    }

    private void loadWeightsFromDatabase() {
        if (weightGrid == null) return;

        // Clear old rows (keep header row)
        int childCount = weightGrid.getChildCount();
        if (childCount > HEADER_CELL_COUNT) {
            weightGrid.removeViews(HEADER_CELL_COUNT, childCount - HEADER_CELL_COUNT);
        }

        // Pull weights from database
        Cursor cursor = dbHelper.getWeightsForUser(userId);
        if (cursor == null) return;

        // Add each row to the grid
        while (cursor.moveToNext()) {
            long weightId = cursor.getLong(cursor.getColumnIndexOrThrow(WeightTrackerDBHelper.COLUMN_WEIGHT_ID));
            String date = cursor.getString(cursor.getColumnIndexOrThrow(WeightTrackerDBHelper.COLUMN_WEIGHT_DATE));
            float weightValue = cursor.getFloat(cursor.getColumnIndexOrThrow(WeightTrackerDBHelper.COLUMN_WEIGHT_VALUE));

            addWeightRowToGrid(weightId, date, weightValue);
        }

        cursor.close();
    }

    private void addWeightRowToGrid(final long weightId, String date, float weightValue) {
        // A row that holds date, weight, delete button
        LinearLayout rowLayout = new LinearLayout(this);
        rowLayout.setOrientation(LinearLayout.HORIZONTAL);
        rowLayout.setBackgroundResource(R.drawable.row_border);
        rowLayout.setPadding(12, 12, 12, 12);

        // Make row stretch across all 3 columns
        GridLayout.LayoutParams rowParams = new GridLayout.LayoutParams();
        rowParams.width = GridLayout.LayoutParams.MATCH_PARENT;
        rowParams.height = GridLayout.LayoutParams.WRAP_CONTENT;
        rowParams.columnSpec = GridLayout.spec(0, 3);
        rowParams.setMargins(8, 8, 8, 8);
        rowLayout.setLayoutParams(rowParams);

        // Date cell
        TextView dateTextView = new TextView(this);
        dateTextView.setText(date);
        dateTextView.setTextSize(16);
        dateTextView.setTextColor(0xFF333333);
        dateTextView.setLayoutParams(new LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1));

        // Weight cell
        final TextView weightTextView = new TextView(this);
        weightTextView.setText(weightValue + " lbs");
        weightTextView.setTextSize(16);
        weightTextView.setTextColor(0xFF333333);
        weightTextView.setLayoutParams(new LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1));
        weightTextView.setOnClickListener(v -> showUpdateWeightDialog(weightId, weightTextView));

        // Delete button
        Button deleteButton = new Button(this);
        deleteButton.setText("X");
        deleteButton.setAllCaps(false);
        deleteButton.setTextColor(Color.WHITE);
        deleteButton.setBackgroundColor(Color.parseColor("#FF0055"));
        deleteButton.setLayoutParams(new LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1));
        deleteButton.setOnClickListener(v -> {
            dbHelper.deleteWeight(weightId);
            loadWeightsFromDatabase();
        });

        // Add cells to row
        rowLayout.addView(dateTextView);
        rowLayout.addView(weightTextView);
        rowLayout.addView(deleteButton);

        // Add row into the grid
        weightGrid.addView(rowLayout);
    }

    private void showAddEntryDialog() {
        // Popup inputs for date + weight
        LinearLayout layout = new LinearLayout(this);
        layout.setOrientation(LinearLayout.VERTICAL);
        int padding = (int) (16 * getResources().getDisplayMetrics().density);
        layout.setPadding(padding, padding, padding, padding);

        final EditText dateInput = new EditText(this);
        dateInput.setHint("Date (e.g., 01/15)");

        final EditText weightInput = new EditText(this);
        weightInput.setHint("Weight (e.g., 165)");
        weightInput.setInputType(android.text.InputType.TYPE_CLASS_NUMBER | android.text.InputType.TYPE_NUMBER_FLAG_DECIMAL);

        layout.addView(dateInput);
        layout.addView(weightInput);

        new AlertDialog.Builder(this).setTitle("Add New Entry").setView(layout).setPositiveButton("Save", (dialog, which) -> {
            String date = dateInput.getText().toString().trim();
            String weightStr = weightInput.getText().toString().trim();

            if (date.isEmpty() || weightStr.isEmpty()) {
                Toast.makeText(this, "Fill in both fields.", Toast.LENGTH_SHORT).show();
                return;
            }

            try {
                float newWeight = Float.parseFloat(weightStr);

                long result = dbHelper.insertWeight(userId, date, newWeight);
                if (result != -1) {
                    Toast.makeText(this, "Saved.", Toast.LENGTH_SHORT).show();
                    loadWeightsFromDatabase();

                    // Check goal after saving
                    checkGoalReachedAndNotify(newWeight);
                } else {
                    Toast.makeText(this, "Could not save.", Toast.LENGTH_SHORT).show();
                }
            } catch (NumberFormatException e) {
                Toast.makeText(this, "Weight must be a number.", Toast.LENGTH_SHORT).show();
            }
        }).setNegativeButton("Cancel", null).show();
    }

    private void showUpdateWeightDialog(final long weightId, final TextView weightTextView) {
        // Get the number of lbs
        String currentText = weightTextView.getText().toString().replace(" lbs", "").trim();

        final EditText input = new EditText(this);
        input.setInputType(android.text.InputType.TYPE_CLASS_NUMBER | android.text.InputType.TYPE_NUMBER_FLAG_DECIMAL);
        input.setText(currentText);
        input.setSelection(input.getText().length());

        new AlertDialog.Builder(this).setTitle("Update Weight").setView(input).setPositiveButton("Update", (dialog, which) -> {
            String newStr = input.getText().toString().trim();
            if (newStr.isEmpty()) {
                Toast.makeText(this, "Weight cannot be empty.", Toast.LENGTH_SHORT).show();
                return;
            }

            try {
                float newWeight = Float.parseFloat(newStr);

                int rows = dbHelper.updateWeight(weightId, newWeight);
                if (rows > 0) {
                    Toast.makeText(this, "Updated.", Toast.LENGTH_SHORT).show();
                    loadWeightsFromDatabase();

                    // Check goal after updating
                    checkGoalReachedAndNotify(newWeight);
                } else {
                    Toast.makeText(this, "Update failed.", Toast.LENGTH_SHORT).show();
                }
            } catch (NumberFormatException e) {
                Toast.makeText(this, "Weight must be a number.", Toast.LENGTH_SHORT).show();
            }
        }).setNegativeButton("Cancel", null).show();
    }

    // ***** SMS goal check

    private SharedPreferences smsPrefs() {
        // Stores SMS settings (on/off and checkboxes)
        return getSharedPreferences(PREFS_SMS, MODE_PRIVATE);
    }

    private SharedPreferences wtPrefs() {
        // Stores goal weight
        return getSharedPreferences(PREFS_WT, MODE_PRIVATE);
    }

    private boolean smsEnabled() {
        // Main SMS switch
        return smsPrefs().getBoolean(KEY_SMS_ENABLED, false);
    }

    private boolean goalSmsEnabled() {
        // Goal checkbox
        return smsPrefs().getBoolean(KEY_GOAL_ALERT, false);
    }

    private float getGoalWeight() {
        // Same key GoalActivity uses
        return wtPrefs().getFloat(username + "_goal_weight", -1f);
    }

    private void checkGoalReachedAndNotify(float newWeight) {
        // Only run if user turned it on
        if (!smsEnabled()) return;
        if (!goalSmsEnabled()) return;

        float goal = getGoalWeight();
        if (goal <= 0) return;

        // Treat goal as "hit" if within 2 lbs
        float diff = Math.abs(newWeight - goal);
        if (diff <= 2f) {
            sendSmsIfPossible("Weight Tracker: You hit your goal weight! We are so proud of you! (" + goal + " lbs)");
        }
    }

    private void sendSmsIfPossible(String message) {
        // Must have permission
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.SEND_SMS) != PackageManager.PERMISSION_GRANTED) {
            return;
        }

        try {
            // Emulator placeholder number
            String fakeNumber = "5554";
            SmsManager.getDefault().sendTextMessage(fakeNumber, null, message, null, null);

            // Message log
            Toast.makeText(this, "Text alert sent.", Toast.LENGTH_SHORT).show();
        } catch (Exception e) {
            // Don't crash if SMS fails
            Toast.makeText(this, "Text alert could not send.", Toast.LENGTH_SHORT).show();
        }
    }
}