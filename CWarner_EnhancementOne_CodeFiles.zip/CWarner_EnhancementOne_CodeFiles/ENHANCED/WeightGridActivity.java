package com.example.codywarner_weighttrackerapp;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import android.Manifest;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.database.Cursor;
import android.graphics.Color;
import android.os.Bundle;
import android.telephony.SmsManager;
import android.widget.Button;
import android.widget.EditText;
import android.widget.GridLayout;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import androidx.core.content.ContextCompat;

/**
 * WeightGridActivity
 *
 * Shows the logged user's weight entries in a grid.
 * Users can add, edit, and delete entries. Deleting requires confirmation
 * to prevent accidental data loss. When a new weight is saved or updated,
 * the app checks if the user hit their goal and sends an SMS if enabled.
 *
 * CS 499 Capstone - Enhancement One changes:
 * - Validation logic for weight and date moved into reusable helper methods
 * - Grid refresh moved into one method instead of repeated inline calls
 * - Toast messages moved into one helper method instead of repeated boilerplate
 * - Delete now shows a confirmation dialog before removing the entry
 * - Weight must be between 1 and 1000 lbs
 * - Date must be in MM/DD/YYYY format with a 4-digit year
 * - Hardcoded numbers replaced with named constants for better readability
 */
public class WeightGridActivity extends AppCompatActivity {

    // =========================================================================
    // Constants
    // =========================================================================

    /**
     * Minimum valid weight in pounds
     */
    private static final float MIN_WEIGHT_LBS = 1f;

    /**
     * Maximum valid weight in pounds
     */
    private static final float MAX_WEIGHT_LBS = 1000f;

    /**
     * Date must be entered as MM/DD/YYYY (01/15/2025).
     * The year is required so entries sort correctly when spanning multiple years.
     */
    private static final String DATE_PATTERN = "^(0[1-9]|1[0-2])/(0[1-9]|[12]\\d|3[01])/\\d{4}$";

    /**
     * Number of header cells (Date / Weight / Delete) pinned at the top of the grid.
     */
    private static final int HEADER_CELL_COUNT = 3;

    /**
     * SharedPreferences file name for SMS settings.
     */
    private static final String PREFS_SMS = "sms_prefs";

    /**
     * SharedPreferences file name for goal weight.
     */
    private static final String PREFS_WT = "wt_prefs";

    /**
     * Key for the SMS on/off switch.
     */
    private static final String KEY_SMS_ENABLED = "sms_enabled";

    /**
     * Key for the goal-reached SMS alert toggle.
     */
    private static final String KEY_GOAL_ALERT = "goal_alert";

    /**
     * How close the user needs to be to their goal to trigger the
     * congrats SMS notification. Removed Hardcoded number.
     */
    private static final float GOAL_WITHIN_LBS = 2f;

    // =========================================================================
    // Views
    // =========================================================================

    private GridLayout weightGrid;
    private TextView tabDailyWeights;
    private TextView tabProgressGraph;
    private TextView tabGoal;
    private TextView tabSettings;

    // =========================================================================
    // Other Variables
    // =========================================================================

    private WeightTrackerDBHelper dbHelper;
    private String username;
    private int userId = -1;

    // =========================================================================
    // Initialization
    // =========================================================================

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_weight_grid);

        // Retrieve the username passed from the login screen
        username = getIntent().getStringExtra("username");
        if (username == null || username.trim().isEmpty()) {
            showToast("No user found.");
            finish();
            return;
        }

        // Initialize the database helper and resolve the numeric user ID
        dbHelper = new WeightTrackerDBHelper(this);
        userId = dbHelper.getUserId(username);

        if (userId == -1) {
            showToast("Could not load account.");
            finish();
            return;
        }

        // Bind views
        weightGrid = findViewById(R.id.weightGrid);
        Button buttonAddEntry = findViewById(R.id.buttonAddEntry);
        tabDailyWeights = findViewById(R.id.tabDailyWeights);
        tabProgressGraph = findViewById(R.id.tabProgressGraph);
        tabGoal = findViewById(R.id.tabGoal);
        tabSettings = findViewById(R.id.tabSettings);

        setupBottomNav();
        refreshWeightGrid();

        buttonAddEntry.setOnClickListener(v -> showAddEntryDialog());
    }

    @Override
    protected void onResume() {
        super.onResume();
        // Re-load entries when the user navigates back from another screen
        refreshWeightGrid();
    }

    // =========================================================================
    // Navigation
    // =========================================================================

    /**
     * Sets up the bottom navigation tabs.
     * Highlights the current tab and sets up the other tabs to navigate
     * to their matching screens when tapped.
     */
    private void setupBottomNav() {
        final int activeColor = Color.WHITE;
        final int inactiveColor = Color.parseColor("#FFD6DE");

        tabDailyWeights.setTextColor(inactiveColor);
        tabProgressGraph.setTextColor(inactiveColor);
        tabGoal.setTextColor(inactiveColor);
        tabSettings.setTextColor(inactiveColor);

        tabDailyWeights.setTextColor(activeColor);

        tabDailyWeights.setOnClickListener(v -> { /* already here */ });

        tabProgressGraph.setOnClickListener(v -> {
            Intent i = new Intent(WeightGridActivity.this, ProgressActivity.class);
            i.putExtra("username", username);
            startActivity(i);
        });

        tabGoal.setOnClickListener(v -> {
            Intent i = new Intent(WeightGridActivity.this, GoalActivity.class);
            i.putExtra("username", username);
            startActivity(i);
        });

        tabSettings.setOnClickListener(v -> {
            Intent i = new Intent(WeightGridActivity.this, SmsNotificationActivity.class);
            i.putExtra("username", username);
            startActivity(i);
        });
    }

    // =========================================================================
    // Grid display
    // =========================================================================

    /**
     * Clears the grid and reloads all weight entries from the database.
     * Having this in one place means add, update, and delete all use
     * the same refresh logic instead of each doing it separately.
     */
    private void refreshWeightGrid() {
        if (weightGrid == null) return;

        // Remove all rows below the fixed header row
        int childCount = weightGrid.getChildCount();
        if (childCount > HEADER_CELL_COUNT) {
            weightGrid.removeViews(HEADER_CELL_COUNT, childCount - HEADER_CELL_COUNT);
        }

        Cursor cursor = dbHelper.getWeightsForUser(userId);
        if (cursor == null) return;

        while (cursor.moveToNext()) {
            long weightId = cursor.getLong(cursor.getColumnIndexOrThrow(WeightTrackerDBHelper.COLUMN_WEIGHT_ID));
            String date = cursor.getString(cursor.getColumnIndexOrThrow(WeightTrackerDBHelper.COLUMN_WEIGHT_DATE));
            float weightValue = cursor.getFloat(cursor.getColumnIndexOrThrow(WeightTrackerDBHelper.COLUMN_WEIGHT_VALUE));
            addWeightRowToGrid(weightId, date, weightValue);
        }

        cursor.close();
    }

    /**
     * Builds one row in the weight grid for a single entry.
     * Each row shows the date, the weight, and a delete button.
     * Tapping the weight opens the edit dialog.
     * Tapping delete opens a confirmation dialog before removing the entry.
     */
    private void addWeightRowToGrid(final long weightId, String date, float weightValue) {
        LinearLayout rowLayout = new LinearLayout(this);
        rowLayout.setOrientation(LinearLayout.HORIZONTAL);
        rowLayout.setBackgroundResource(R.drawable.row_border);
        rowLayout.setPadding(12, 12, 12, 12);

        GridLayout.LayoutParams rowParams = new GridLayout.LayoutParams();
        rowParams.width = GridLayout.LayoutParams.MATCH_PARENT;
        rowParams.height = GridLayout.LayoutParams.WRAP_CONTENT;
        rowParams.columnSpec = GridLayout.spec(0, 3);
        rowParams.setMargins(8, 8, 8, 8);
        rowLayout.setLayoutParams(rowParams);

        // Date (read-only)
        TextView dateTextView = new TextView(this);
        dateTextView.setText(date);
        dateTextView.setTextSize(16);
        dateTextView.setTextColor(0xFF333333);
        dateTextView.setLayoutParams(new LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1));

        // Weight (tappable - opens update option)
        final TextView weightTextView = new TextView(this);
        weightTextView.setText(weightValue + " lbs");
        weightTextView.setTextSize(16);
        weightTextView.setTextColor(0xFF333333);
        weightTextView.setLayoutParams(new LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1));
        weightTextView.setOnClickListener(v -> showUpdateWeightDialog(weightId, weightTextView));

        // Delete button (opens confirmation)
        Button deleteButton = new Button(this);
        deleteButton.setText("X");
        deleteButton.setAllCaps(false);
        deleteButton.setTextColor(Color.WHITE);
        deleteButton.setBackgroundColor(Color.parseColor("#FF0055"));
        deleteButton.setLayoutParams(new LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1));
        deleteButton.setOnClickListener(v -> showDeleteConfirmationDialog(weightId));

        rowLayout.addView(dateTextView);
        rowLayout.addView(weightTextView);
        rowLayout.addView(deleteButton);

        weightGrid.addView(rowLayout);
    }

    // =========================================================================
    // Dialogs
    // =========================================================================

    /**
     * Shows a popup where the user can enter a date and weight to save a new entry.
     * Both fields are validated before anything is written to the database.
     */
    private void showAddEntryDialog() {
        LinearLayout layout = new LinearLayout(this);
        layout.setOrientation(LinearLayout.VERTICAL);
        int padding = (int) (16 * getResources().getDisplayMetrics().density);
        layout.setPadding(padding, padding, padding, padding);

        final EditText dateInput = new EditText(this);
        dateInput.setHint("Date (e.g., 01/15/2025)");

        final EditText weightInput = new EditText(this);
        weightInput.setHint("Weight (e.g., 165)");
        weightInput.setInputType(android.text.InputType.TYPE_CLASS_NUMBER | android.text.InputType.TYPE_NUMBER_FLAG_DECIMAL);

        layout.addView(dateInput);
        layout.addView(weightInput);

        new AlertDialog.Builder(this).setTitle("Add New Entry").setView(layout).setPositiveButton("Save", (dialog, which) -> {
            String date = dateInput.getText().toString().trim();
            String weightStr = weightInput.getText().toString().trim();

            if (!isValidDate(date)) return;
            if (!isValidWeight(weightStr)) return;

            float newWeight = Float.parseFloat(weightStr);
            long result = dbHelper.insertWeight(userId, date, newWeight);

            if (result != -1) {
                showToast("Saved.");
                refreshWeightGrid();
                checkGoalReachedAndNotify(newWeight);
            } else {
                showToast("Could not save.");
            }
        }).setNegativeButton("Cancel", null).show();
    }

    /**
     * Shows a popup where the user can update the weight for an existing entry.
     * The current weight is pre-filled so the user can see what they are changing.
     * The new value is validated before the database is updated.
     */
    private void showUpdateWeightDialog(final long weightId, final TextView weightTextView) {
        String currentText = weightTextView.getText().toString().replace(" lbs", "").trim();

        final EditText input = new EditText(this);
        input.setInputType(android.text.InputType.TYPE_CLASS_NUMBER | android.text.InputType.TYPE_NUMBER_FLAG_DECIMAL);
        input.setText(currentText);
        input.setSelection(input.getText().length());

        new AlertDialog.Builder(this).setTitle("Update Weight").setView(input).setPositiveButton("Update", (dialog, which) -> {
            String newStr = input.getText().toString().trim();

            if (!isValidWeight(newStr)) return;

            float newWeight = Float.parseFloat(newStr);
            int rows = dbHelper.updateWeight(weightId, newWeight);

            if (rows > 0) {
                showToast("Updated.");
                refreshWeightGrid();
                checkGoalReachedAndNotify(newWeight);
            } else {
                showToast("Update failed.");
            }
        }).setNegativeButton("Cancel", null).show();
    }

    /**
     * Shows a confirmation dialog before deleting an entry.
     * In the original code, tapping X deleted the entry immediately with no warning.
     * Now the user has to confirm before anything is removed.
     */
    private void showDeleteConfirmationDialog(final long weightId) {
        new AlertDialog.Builder(this).setTitle("Delete Entry").setMessage("Are you sure you want to delete this entry? This cannot be undone.").setPositiveButton("Delete", (dialog, which) -> {
            dbHelper.deleteWeight(weightId);
            refreshWeightGrid();
            showToast("Entry deleted.");
        }).setNegativeButton("Cancel", null).show();
    }

    // =========================================================================
    // Validation helpers
    // =========================================================================

    /**
     * Checks that the date the user entered is in MM/DD/YYYY format with a 4-digit year.
     * The year is required so entries sort correctly across multiple years.
     * Shows an error message and returns false if the input does not match.
     */
    private boolean isValidDate(String date) {
        if (date.isEmpty()) {
            showToast("Date cannot be empty.");
            return false;
        }
        if (!date.matches(DATE_PATTERN)) {
            showToast("Date must be MM/DD/YYYY (e.g., 01/15/2025).");
            return false;
        }
        return true;
    }

    /**
     * Checks that the weight the user entered is a valid number between 1 and 1000 lbs.
     * Shows an error message and returns false if the input is empty, not a number,
     * or outside that range. This replaced duplicate validation code that existed
     * separately in both the add and update dialogs in the original.
     */
    private boolean isValidWeight(String weightStr) {
        if (weightStr.isEmpty()) {
            showToast("Weight cannot be empty.");
            return false;
        }
        try {
            float weight = Float.parseFloat(weightStr);
            if (weight <= MIN_WEIGHT_LBS) {
                showToast("Weight must be greater than " + MIN_WEIGHT_LBS + " lbs.");
                return false;
            }
            if (weight > MAX_WEIGHT_LBS) {
                showToast("Weight cannot exceed " + MAX_WEIGHT_LBS + " lbs.");
                return false;
            }
        } catch (NumberFormatException e) {
            showToast("Weight must be a valid number.");
            return false;
        }
        return true;
    }

    // =========================================================================
    // UI helpers
    // =========================================================================

    /**
     * Shows a short Toast message on screen.
     * Used throughout the class instead of repeating the full
     * Toast.makeText line every time a message needs to be displayed.
     */
    private void showToast(String message) {
        Toast.makeText(this, message, Toast.LENGTH_SHORT).show();
    }

    // =========================================================================
    // Goal + SMS notification
    // =========================================================================

    private SharedPreferences smsPrefs() {
        return getSharedPreferences(PREFS_SMS, MODE_PRIVATE);
    }

    private SharedPreferences wtPrefs() {
        return getSharedPreferences(PREFS_WT, MODE_PRIVATE);
    }

    private boolean smsEnabled() {
        return smsPrefs().getBoolean(KEY_SMS_ENABLED, false);
    }

    private boolean goalSmsEnabled() {
        return smsPrefs().getBoolean(KEY_GOAL_ALERT, false);
    }

    private float getGoalWeight() {
        return wtPrefs().getFloat(username + "_goal_weight", -1f);
    }

    /**
     * Checks if the new weight is within 2 lbs of the user's goal weight.
     * If it is, and if SMS notifications are turned on, sends a congratulatory text.
     */
    private void checkGoalReachedAndNotify(float newWeight) {
        if (!smsEnabled()) return;
        if (!goalSmsEnabled()) return;

        float goal = getGoalWeight();
        if (goal <= 0) return;

        if (Math.abs(newWeight - goal) <= GOAL_WITHIN_LBS) {
            sendSmsIfPossible("Weight Tracker: You hit your goal weight! We are so proud of you! (" + goal + " lbs)");
        }
    }

    /**
     * Sends an SMS text message if the app has permission to do so.
     * If sending fails, like on an emulator or a phone without a SIM card,
     * the error is caught so the app does not crash.
     */
    private void sendSmsIfPossible(String message) {
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.SEND_SMS) != PackageManager.PERMISSION_GRANTED) {
            return;
        }
        try {
            SmsManager.getDefault().sendTextMessage("5554", null, message, null, null);
            showToast("Text alert sent.");
        } catch (Exception e) {
            showToast("Text alert could not send.");
        }
    }
}
