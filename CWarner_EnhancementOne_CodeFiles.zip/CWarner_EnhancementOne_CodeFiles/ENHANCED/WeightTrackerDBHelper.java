package com.example.codywarner_weighttrackerapp;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;


// Class for apps database
public class WeightTrackerDBHelper extends SQLiteOpenHelper {

    private static final String DATABASE_NAME = "weight_tracker.db";
    private static final int DATABASE_VERSION = 2;

    // USERS TABLE: Stores login info
    public static final String TABLE_USERS = "users";
    public static final String COLUMN_USER_ID = "id";
    public static final String COLUMN_USERNAME = "username";
    public static final String COLUMN_PASSWORD = "password";

    // WEIGHTS TABLE: Stores weight entries
    public static final String TABLE_WEIGHTS = "weights";
    public static final String COLUMN_WEIGHT_ID = "id";
    public static final String COLUMN_WEIGHT_DATE = "entry_date";
    public static final String COLUMN_WEIGHT_VALUE = "weight_value";
    public static final String COLUMN_WEIGHT_USER_ID = "user_id";

    public WeightTrackerDBHelper(Context context) {
        super(context, DATABASE_NAME, null, DATABASE_VERSION);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        // Create users table
        String createUsersTable = "CREATE TABLE " + TABLE_USERS + " (" + COLUMN_USER_ID + " INTEGER PRIMARY KEY AUTOINCREMENT, " + COLUMN_USERNAME + " TEXT UNIQUE, " + COLUMN_PASSWORD + " TEXT" + ");";

        // Create weights table
        String createWeightsTable = "CREATE TABLE " + TABLE_WEIGHTS + " (" + COLUMN_WEIGHT_ID + " INTEGER PRIMARY KEY AUTOINCREMENT, " + COLUMN_WEIGHT_USER_ID + " INTEGER, " + COLUMN_WEIGHT_DATE + " TEXT, " + COLUMN_WEIGHT_VALUE + " REAL" + ");";

        db.execSQL(createUsersTable);
        db.execSQL(createWeightsTable);
    }

    // Used for runnning when DATABASE_VERSION changes
    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        db.execSQL("DROP TABLE IF EXISTS " + TABLE_WEIGHTS);
        db.execSQL("DROP TABLE IF EXISTS " + TABLE_USERS);
        onCreate(db);
    }

    // ** USER METHODS

    // Create a new user. Returns true if success, false if username exists.
    public boolean registerUser(String username, String password) {
        SQLiteDatabase db = this.getWritableDatabase();

        // Doesn't allow duplicate usernames
        if (userExists(username)) {
            return false;
        }

        // Puts value into objects
        ContentValues values = new ContentValues();
        values.put(COLUMN_USERNAME, username);
        values.put(COLUMN_PASSWORD, password);

        long result = db.insert(TABLE_USERS, null, values);
        return result != -1;
    }

    // Check if username/password combo is valid
    public boolean checkUserLogin(String username, String password) {
        SQLiteDatabase db = this.getReadableDatabase();

        // If a match exists, request the ID column
        String[] columns = {COLUMN_USER_ID};
        String selection = COLUMN_USERNAME + " = ? AND " + COLUMN_PASSWORD + " = ?";
        String[] selectionArgs = {username, password};

        Cursor cursor = db.query(TABLE_USERS, columns, selection, selectionArgs, null, null, null);

        boolean hasUser = (cursor != null && cursor.getCount() > 0);

        if (cursor != null) {
            cursor.close();
        }

        return hasUser;
    }

    // Checks if username already exists
    public boolean userExists(String username) {
        SQLiteDatabase db = this.getReadableDatabase();

        String[] columns = {COLUMN_USER_ID};
        String selection = COLUMN_USERNAME + " = ?";
        String[] selectionArgs = {username};

        Cursor cursor = db.query(TABLE_USERS, columns, selection, selectionArgs, null, null, null);

        boolean exists = (cursor != null && cursor.getCount() > 0);

        if (cursor != null) {
            cursor.close();
        }

        return exists;
    }

    // Looks up the user's ID using their username. The link between the user and their weight entries
    public int getUserId(String username) {
        SQLiteDatabase db = this.getReadableDatabase();

        String[] columns = {COLUMN_USER_ID};
        String selection = COLUMN_USERNAME + " = ?";
        String[] selectionArgs = {username};

        Cursor cursor = db.query(TABLE_USERS, columns, selection, selectionArgs, null, null, null);

        int userId = -1;

        if (cursor != null && cursor.moveToFirst()) {
            int index = cursor.getColumnIndex(COLUMN_USER_ID);
            if (index >= 0) {
                userId = cursor.getInt(index);
            }
        }

        if (cursor != null) {
            cursor.close();
        }

        return userId;
    }

    // ** WEIGHT METHODS
    // CRUD

    // CREATE: insert a weight entry for a username
    public long insertWeight(int userId, String date, float weightValue) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put(COLUMN_WEIGHT_USER_ID, userId);
        values.put(COLUMN_WEIGHT_DATE, date);
        values.put(COLUMN_WEIGHT_VALUE, weightValue);
        return db.insert(TABLE_WEIGHTS, null, values);
    }

    /** READ: Gets all weight entries for the user, sorted newest to oldest.
    * Since dates are stored as MM/DD/YYYY, a normal sort would order by month
    * first which gives the wrong order across multiple years. Instead, the year,
    * month, and day are pulled out separately so the sort works correctly.
    */
    public Cursor getWeightsForUser(int userId) {
        SQLiteDatabase db = this.getReadableDatabase();
        String sortOrder = "substr(" + COLUMN_WEIGHT_DATE + ",7,4) DESC, " + "substr(" + COLUMN_WEIGHT_DATE + ",1,2) DESC, " + "substr(" + COLUMN_WEIGHT_DATE + ",4,2) DESC";
        return db.query(TABLE_WEIGHTS, null, COLUMN_WEIGHT_USER_ID + "=?", new String[]{String.valueOf(userId)}, null, null, sortOrder);
    }

    // UPDATE a weight entry
    public int updateWeight(long id, float newWeight) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put(COLUMN_WEIGHT_VALUE, newWeight);
        return db.update(TABLE_WEIGHTS, values, COLUMN_WEIGHT_ID + "=?", new String[]{String.valueOf(id)});
    }

    // DELETE a weight entry
    public int deleteWeight(long id) {
        SQLiteDatabase db = this.getWritableDatabase();
        return db.delete(TABLE_WEIGHTS, COLUMN_WEIGHT_ID + "=?", new String[]{String.valueOf(id)});
    }
}
