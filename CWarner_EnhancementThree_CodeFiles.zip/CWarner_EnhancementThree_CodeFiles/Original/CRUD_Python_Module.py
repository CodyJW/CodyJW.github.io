# Example Python Code to Insert a Document 

from pymongo import MongoClient 
from bson.objectid import ObjectId
from pymongo.errors import PyMongoError #Error handling 

class AnimalShelter(object): 
    """ CRUD operations for Animal collection in MongoDB """ 

    def __init__(self, username, pw): 
        # Initializing the MongoClient. This helps to access the MongoDB 
        # databases and collections. This is hard-wired to use the aac 
        # database, the animals collection, and the aac user. 
        # 
        # You must edit the password below for your environment. 
        # 
        # Connection Variables 
        # 

        HOST = 'localhost' 
        PORT = 27017 
        DB = 'aac' 
        COL = 'animals' 
        # 
        # Initialize Connection 
        # 
        self.client = MongoClient('mongodb://%s:%s@%s:%d' % (username,pw,HOST,PORT)) 
        self.database = self.client['%s' % (DB)] 
        self.collection = self.database['%s' % (COL)] 

    def doThing(self):
            return 'hello'
        
    # Create a method to return the next available record number for use in the create method
            
    # Complete this create method to implement the C in CRUD. 
    def create(self, data):
        # insert one document. if insert success, return true, else false.
        if not isinstance(data, dict) or not data:
            return False
        try:
            result = self.collection.insert_one(data)
            return bool(result.acknowledged and result.inserted_id)
        # error handling
        except Exception:
            return False

    # Create method to implement the R in CRUD.
    def read(self, query=None):
        # Use find() and return a list of documents
        try:
            q = query or {}
            cursor = self.collection.find(q)
            return list(cursor)
        # error handling
        except Exception:
            return [] # return empty list
        
    # Method for implementing the U in CRUD
    def update(self, query, new_values, many=False): ## new_values is the dict of fields
        # Validate the inputs
        if not isinstance(query, dict) or not query:
            return 0
        if not isinstance(new_values, dict) or not new_values:
            return 0
        try:
            if many:
                result = self.collection.update_many(query, {"$set": new_values})
            else:
                result = self.collection.update_one(query, {"$set": new_values})
            return int(result.modified_count or 0) ## counts how many documents were modified, returns zero if the doc already had these values given
        except Exception:
            return 0
    
    
    # Method for implementing the D in CRUD
    def delete(self, query, many=False):
        # Validates the inputs
        if not isinstance(query, dict) or not query:
            return 0
        try:
            if many:
                result = self.collection.delete_many(query)
            else:
                result = self.collection.delete_one(query)
            return int(result.deleted_count or 0) ## counts how many docs were removed
        except Exception:
            ## no deletion performed
            return 0