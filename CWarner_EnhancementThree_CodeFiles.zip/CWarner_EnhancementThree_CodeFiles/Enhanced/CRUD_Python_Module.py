from pymongo import MongoClient
from pymongo.errors import PyMongoError


class AnimalShelter(object):
    """ CRUD operations for Animal collection in MongoDB """ 

    def __init__(self, username, pw):
        # Initializing the MongoClient. This helps to access the MongoDB 
        # databases and collections. This is hard-wired to use the aac 
        # database, the animals collection, and the aac user. 
        # 
        # You must edit the password below for your environment. 
        # 
        # Connection Variables 
        # 
        HOST = 'localhost'
        PORT = 27017
        DB = 'aac'
        COL = 'animals'

        try:
            # Create the MongoDB client and select the database/collection
            self.client = MongoClient('mongodb://%s:%s@%s:%d' % (username, pw, HOST, PORT))
            self.database = self.client[DB]
            self.collection = self.database[COL]

            # Verify the connection is reachable
            self.client.admin.command('ping')
            print("Connected to database successfully.")
        
        # If the connection fails, set these to None so later methods can fail safely
        except PyMongoError as e:
            print("Failed to connect to database:", e)
            self.client = None
            self.database = None
            self.collection = None

    # C in CRUD
    def create(self, data):

        #prevent database operations when there is no active connection
        if not self.is_connected():
            print("Create failed: no active database connection.")
            return False

        # Reject empty input or anything that is not a dictionary
        if not isinstance(data, dict) or not data:
            print("Create failed: input must be a non-empty dictionary.")
            return False
        try:
            # Insert the document and return True if successful
            result = self.collection.insert_one(data)
            return bool(result.acknowledged and result.inserted_id)
        except PyMongoError as e:
            print("Database error during create:", e)
            return False

    # R in CRUD
    def read(self, query=None, projection=None):

        # prevent database operations when there is no active connection
        if not self.is_connected():
            print("Read failed: no active database connection.")
            return []
        
        # Query must be a dictionary if provided
        if query is not None and not isinstance(query, dict):
            print("Read failed: query must be a dictionary.")
            return []
        try:
            q = query or {}
            # Use projection if provided to limit which fields are returned
            cursor = self.collection.find(q, projection) if projection else self.collection.find(q)
            return list(cursor)
        except PyMongoError as e:
            print("Database error during read:", e)
            return []

    # U in CRUD
    def update(self, query, new_values, many=False):

        # prevent database operations when there is no active connection
        if not self.is_connected():
            print("Update failed: no active database connection.")
            return 0

        # Both query and new_values must be non-empty dictionaries
        if not isinstance(query, dict) or not query:
            print("Update failed: query must be a non-empty dictionary.")
            return 0
        if not isinstance(new_values, dict) or not new_values:
            print("Update failed: new_values must be a non-empty dictionary.")
            return 0
        try:
            # Update all matches if many=True, otherwise just the first
            if many:
                result = self.collection.update_many(query, {"$set": new_values})
            else:
                result = self.collection.update_one(query, {"$set": new_values})
            return int(result.modified_count or 0) # counts how many documents were modified
        except PyMongoError as e:
            print("Database error during update:", e)
            return 0

    # D in CRUD
    def delete(self, query, many=False):
        
        # prevent database operations when there is no active connection
        if not self.is_connected():
            print("Delete failed: no active database connection.")
            return 0
        
        # Reject empty query to prevent accidentally deleting the entire collection
        if not isinstance(query, dict) or not query:
            print("Delete failed: query must be a non-empty dictionary.")
            return 0
        try:
            # Delete all matches if many=True, otherwise just the first
            if many:
                result = self.collection.delete_many(query)
            else:
                result = self.collection.delete_one(query)
            return int(result.deleted_count or 0) # counts how many docs were removed
        except PyMongoError as e:
            print("Database error during delete:", e)
            return 0

    # Helper method that returns True only when the MongoDB collection was successfully initialized
    def is_connected(self):
        return self.collection is not None